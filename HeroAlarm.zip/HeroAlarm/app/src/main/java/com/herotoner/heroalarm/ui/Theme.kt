package com.herotoner.heroalarm.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

val Bg = Color(0xFF0B1226)
val CardBg = Color(0xFF151E3A)
val CardHi = Color(0xFF1F2A4D)
val Gold = Color(0xFFE8C887)
val TextMain = Color(0xFFF3F4F8)
val TextDim = Color(0xFF9AA4C0)
val Danger = Color(0xFFE5736A)

@Composable
fun HeroTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = CardBg, onSurface = TextMain)) {
        // The whole UI is Arabic, so it is always laid out right-to-left.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(Modifier.fillMaxSize().background(Bg)) { content() }
        }
    }
}
