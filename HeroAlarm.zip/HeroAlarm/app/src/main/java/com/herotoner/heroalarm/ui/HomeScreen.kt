package com.herotoner.heroalarm.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herotoner.heroalarm.R
import com.herotoner.heroalarm.alarm.AlarmTime
import com.herotoner.heroalarm.data.Alarm
import kotlinx.coroutines.delay
import java.util.Calendar

@Composable
fun HomeScreen(
    alarms: List<Alarm>,
    onAdd: () -> Unit,
    onEdit: (Alarm) -> Unit,
    onDelete: (Alarm) -> Unit,
    onToggle: (Alarm) -> Unit,
    onDisableAll: () -> Unit,
    onTest: () -> Unit,
) {
    val now by produceState(System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(1000) }
    }
    val addFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { addFocus.requestFocus() } }

    Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 28.dp)) {
        // Header: logo (right in RTL) and live clock/date (left)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Image(painterResource(R.drawable.ic_bell), null, Modifier.size(44.dp), colorFilter = ColorFilter.tint(Gold))
                Text("HERO ALARM", color = Gold, fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            }
            Column(horizontalAlignment = Alignment.Start) {
                Text(fmtClock(now), color = TextMain, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                Text(fmtDate(now), color = TextDim, fontSize = 18.sp)
            }
        }

        Row(Modifier.weight(1f).padding(top = 24.dp), horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            // Sidebar (right in RTL)
            Column(Modifier.width(300.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                HeroButton("＋ إضافة منبّه جديد", onAdd, Modifier.fillMaxWidth().height(96.dp), primary = true, fontSize = 24.sp, focusRequester = addFocus)
                HeroButton("تجربة التنبيه", onTest, Modifier.fillMaxWidth().height(72.dp))
                HeroButton("إيقاف الكل", onDisableAll, Modifier.fillMaxWidth().height(72.dp), danger = true)
            }

            // Main column: next alarm card + list
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                NextAlarmCard(alarms, now)
                if (alarms.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("لا توجد منبّهات بعد. أضف أول منبّه.", color = TextDim, fontSize = 22.sp)
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(alarms, key = { it.id }) { a -> AlarmRow(a, onEdit, onDelete, onToggle) }
                    }
                }
            }
        }
    }
}

@Composable
private fun NextAlarmCard(alarms: List<Alarm>, now: Long) {
    val cal = Calendar.getInstance().apply { timeInMillis = now }
    val next = alarms.filter { it.enabled }
        .map { it to AlarmTime.nextTrigger(it.hour, it.minute, it.daysMask, cal) }
        .minByOrNull { it.second }
    Row(
        Modifier.fillMaxWidth().background(CardBg, RoundedCornerShape(20.dp)).padding(24.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        Image(painterResource(R.drawable.ic_bell), null, Modifier.size(72.dp), colorFilter = ColorFilter.tint(Gold))
        Column(Modifier.weight(1f)) {
            Text("المنبّه القادم", color = TextDim, fontSize = 20.sp)
            if (next == null) {
                Text("لا يوجد منبّه مفعّل", color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            } else {
                Text(fmtTime(next.first.hour, next.first.minute), color = Gold, fontSize = 44.sp, fontWeight = FontWeight.Bold)
                Text("${next.first.title} • بعد ${remainingText(next.second - now)}", color = TextMain, fontSize = 22.sp)
            }
        }
    }
}

@Composable
private fun AlarmRow(a: Alarm, onEdit: (Alarm) -> Unit, onDelete: (Alarm) -> Unit, onToggle: (Alarm) -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(confirm) { if (confirm) { delay(4000); confirm = false } }
    Row(
        Modifier.fillMaxWidth().background(CardBg, RoundedCornerShape(16.dp)).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(fmtTime(a.hour, a.minute), color = if (a.enabled) Gold else TextDim, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(170.dp))
        Column(Modifier.weight(1f)) {
            Text(a.title, color = TextMain, fontSize = 22.sp, maxLines = 1)
            Text(
                daysText(a.daysMask) + if (a.description.isNotBlank()) " • ${a.description}" else "",
                color = TextDim, fontSize = 16.sp, maxLines = 1,
            )
        }
        HeroButton(if (a.enabled) "مفعّل" else "متوقف", { onToggle(a) }, selected = a.enabled, fontSize = 18.sp)
        HeroButton("تعديل", { onEdit(a) }, fontSize = 18.sp)
        HeroButton(if (confirm) "تأكيد الحذف؟" else "حذف", { if (confirm) onDelete(a) else confirm = true }, danger = true, fontSize = 18.sp)
    }
}
