package com.herotoner.heroalarm.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** daysMask: bit (Calendar.DAY_OF_WEEK - 1) set means "repeat on that day". 0 = one-time alarm. */
@Entity(tableName = "alarms")
data class Alarm(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hour: Int = 7,
    val minute: Int = 0,
    val title: String = "",
    val description: String = "",
    val daysMask: Int = 0,
    val soundIndex: Int = 0,
    val volume: Int = 80,
    val enabled: Boolean = true,
    val lastFiredAt: Long = 0,
    val nextTrigger: Long = 0,
)

/** status: RINGING, DISMISSED, TIMEOUT or MISSED. */
@Entity(tableName = "alarm_logs")
data class AlarmLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val alarmId: Long,
    val title: String,
    val firedAt: Long,
    val dismissedAt: Long = 0,
    val status: String,
)
